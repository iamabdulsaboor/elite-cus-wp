<?php

 register_nav_menus(array(
     'primary' => 'Primary Menu', 
     'header'  => 'Header Menu')
    );

    // for feature image function

    add_theme_support('post-thumbnails');

    // for header logo image function

    add_theme_support('custom-header');

    // for background image function

    add_theme_support('custom-background');
?>